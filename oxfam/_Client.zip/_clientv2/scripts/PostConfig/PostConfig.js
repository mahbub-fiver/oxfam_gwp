var pwidget_config = {
    copypaste: false,
    shareQuote: false,
    defaults: {
       afterShare: false
    }
};
